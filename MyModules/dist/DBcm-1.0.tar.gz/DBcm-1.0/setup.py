from setuptools import setup
setup(
name='DBcm',
version='1.0',
description='The Head First Python Search Tools',
author='Sarfraz',
author_email='eng.sarfraze@gmail.com',
url='sarfraz.com',
py_modules=['DBcm'],
)